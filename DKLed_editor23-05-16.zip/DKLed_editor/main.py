# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
#from PyQt5 import QtWidgets, uic
#import sys
#from ReadDKLedLib import Command_Library_Demonstration

Arr1 = [0,1,2,3]
print(Arr1)

arr12 = []
arr12.append(Arr1[0])
arr12.append(Arr1[2])
arr2 = []
arr2.append(Arr1)
arr2.append(arr12)

PP = 0
print(PP)
PP = PP + 1
print (PP)



Arr1.clear()
Arr1 = [5,6]
arr2.append(Arr1)

print(arr2)
print(str(arr2[1]))
print(str(arr2[1][0]))

print(str(int("123")))


text = ' "text text "'
print("["+text+"]")
text = text.strip(" ").replace('"','')
print("["+text+"]")

print(str(" 12Fa   ".replace(" ", "") in "0123456789abcdefABCDEF"))
print("int(one)" + str(int("   12Ad  ",16)))

print(str(8//3))

print()
print("hex rep:__"+hex(14)[2])
print()

class A0:
    A="5"
    B="6"

print(A0.A + "__"+ A0.B)
A0.A = "A0.B"
print(A0.A + "__"+ A0.B)

#Command_Library_Demonstration()
#ui.show()
#app.exec()

#import DKLedMain